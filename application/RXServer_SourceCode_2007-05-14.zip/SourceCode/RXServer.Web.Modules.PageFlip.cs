using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Web;
using iConsulting.iCDataHandler;
using RXServer.Web.Model;
using System.Xml;

namespace RXServer
{
    namespace Web
    {
        namespace Modules
        {

            #region public class PageFlip

            [Serializable]
            public class PageFlip : IDisposable, IEnumerable
            {
                string CLASSNAME = "[Namespace::RXServer.Web.Modules][Class::PageFlip]";

                #region DataHandler Variables

                private string m_datasource;
                private string m_connectionstring;

                #endregion DataHandler Variables

                #region Private Variables

                private PageFlipItem m_object;
                private PageFlipItem[] m_objects;
                private ObjectType m_objecttype = ObjectType.RXServerDefined_Modules_PageFlipItem;
                private Int32 m_sit_id = 0;
                private Int32 m_pag_id = 0;
                private Int32 m_mod_id = 0;
                private Int32 m_obd_parentid = 0;
                private String m_obd_alias = String.Empty;
                private bool m_autoupdate = false;
                private DataTable m_dtobjects;
                private Boolean m_refresh;
                private String m_width = String.Empty;
                private String m_height = String.Empty;
                private Boolean m_hcover = false;
                private Boolean m_transparency = false;
                private String m_prepage = String.Empty;
                private String m_path = String.Empty;

                #endregion Private Variables

                #region Properties

                public IEnumerator GetEnumerator()
                {
                    return new RXPageFlipEnum(this.m_objects);
                }
               
                public PageFlipItem this[Int32 index]
                {
                    get
                    {
                        string FUNCTIONNAME = CLASSNAME + "[Function::PageFlipItem]";
                        try
                        {
                            this.m_object = (PageFlipItem)this.m_objects[index];
                            return this.m_object;
                        }
                        catch (Exception ex)
                        {
                            Error.Report(ex, FUNCTIONNAME, "");
                            return new PageFlipItem();
                        }
                    }
                }

                public PageFlipItem[] Items
                {
                    get
                    {
                        string FUNCTIONNAME = CLASSNAME + "[Function::PageFlipItem]";
                        try
                        {
                            return this.m_objects;
                        }
                        catch (Exception ex)
                        {
                            Error.Report(ex, FUNCTIONNAME, "");
                            return new PageFlipItem[0];
                        }
                    }
                }

                public PageFlipItem GetPageFlipItem(Int32 Id)
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::PageFlipItem]";
                    try
                    {
                        foreach (PageFlipItem o in this.m_objects)
                        {
                            if (o.Id == Id)
                            {
                                return o;
                            }
                        }
                        return new PageFlipItem();
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, "");
                        return new PageFlipItem();
                    }
                }

                public PageFlipItem GetPageFlipItem(string Alias)
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::PageFlipItem]";
                    try
                    {
                        foreach (PageFlipItem o in this.m_objects)
                        {
                            if (o.Alias.ToLower() == Alias.ToLower())
                            {
                                return o;
                            }
                        }
                        return new PageFlipItem();
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, "");
                        return new PageFlipItem();
                    }
                }

                public bool Contains(Int32 Id)
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::Contains]";
                    try
                    {
                        foreach (PageFlipItem o in this.m_objects)
                        {
                            if (o.Id == Id)
                            {
                                return true;
                            }
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, "");
                        return false;
                    }
                }

                public bool Contains(string Alias)
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::Contains]";
                    try
                    {
                        foreach (PageFlipItem o in this.m_objects)
                        {
                            if (o.Alias.ToLower() == Alias.ToLower())
                            {
                                return true;
                            }
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, "");
                        return false;
                    }
                }

                public bool Refresh
                {
                    get
                    {
                        return this.m_refresh;
                    }
                    set
                    {
                        this.m_refresh = value;
                    }
                }

                public String Width
                {
                    get
                    {
                        return this.m_width;
                    }
                    set
                    {
                        this.m_width = value;
                    }
                }

                public String Height
                {
                    get
                    {
                        return this.m_height;
                    }
                    set
                    {
                        this.m_height = value;
                    }
                }

                public Boolean Hcover
                {
                    get
                    {
                        return this.m_hcover;
                    }
                    set
                    {
                        this.m_hcover = value;
                    }
                }

                public Boolean Transparency
                {
                    get
                    {
                        return this.m_transparency;
                    }
                    set
                    {
                        this.m_transparency = value;
                    }
                }

                public String PrePage
                {
                    get
                    {
                        return this.m_prepage;
                    }
                    set
                    {
                        this.m_prepage = value;
                    }
                }

                public String Path
                {
                    get
                    {
                        return this.m_path;
                    }
                    set
                    {
                        this.m_path = value;
                    }
                }
                

                #endregion Properties

                #region Constructors

                public PageFlip() { }

                public PageFlip(Int32 SitId, Int32 PagId, Int32 ModId, String Width, String Height, Boolean Hcover, Boolean Transparency, String PrePage, String Path)
                    : this(SitId, PagId, ModId, Width, Height, Hcover, Transparency, PrePage, Path, true)
                {
                }

                public PageFlip(Int32 SitId, Int32 PagId, Int32 ModId, String Width, String Height, Boolean Hcover, Boolean Transparency, String PrePage, String Path, Boolean Refresh)
                {
                    this.m_datasource = RXServer.Data.DataSource;
                    this.m_connectionstring = RXServer.Data.ConnectionString;
                    this.m_sit_id = SitId;
                    this.m_pag_id = PagId;
                    this.m_mod_id = ModId;
                    this.m_width = Width;
                    this.m_height = Height;
                    this.m_hcover = Hcover;
                    this.m_transparency = Transparency;
                    this.m_prepage = PrePage;
                    this.m_path = Path;
                    this.m_autoupdate = false;
                    this.m_refresh = Refresh;
                    GetAll();
                }

                ~PageFlip()
                {
                    xFinalize();
                }
                public void Dispose()
                {
                    xFinalize();
                    System.GC.SuppressFinalize(this);
                }
                private void xFinalize()
                {
                    if (!this.Refresh)
                        ResetThis();
                    if (RXServer.Data.ActivateGC)
                        GC.Collect();
                }

                #endregion Constructors

                #region Public Methods

                public void Add(PageFlipItem p)
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::Add]";
                    try
                    {
                        this.Add(ref p);
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, "");
                    }
                }
                public void Add(ref PageFlipItem p)
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::Add]";
                    try
                    {
                        DataSet ds = new DataSet();
                        StringBuilder sSQL = new StringBuilder();
                        sSQL.Append("INSERT INTO obd_objectdata (lng_id, obd_parentid, sit_id, pag_id, mod_id, obd_order, obd_type, obd_title, obd_alias, obd_description, obd_varchar1, obd_varchar2, obd_varchar3, obd_varchar4, obd_varchar5, obd_varchar6, obd_varchar7, obd_varchar8, obd_varchar9, obd_varchar10, obd_varchar11, obd_varchar12, obd_varchar13, obd_varchar14, obd_varchar15, obd_varchar16, obd_varchar17, obd_varchar18, obd_varchar19, obd_varchar20, obd_varchar21, obd_varchar22, obd_varchar23, obd_varchar24, obd_varchar25, obd_varchar26, obd_varchar27, obd_varchar28, obd_varchar29, obd_varchar30, obd_varchar31, obd_varchar32, obd_varchar33, obd_varchar34, obd_varchar35, obd_varchar36, obd_varchar37, obd_varchar38, obd_varchar39, obd_varchar40, obd_varchar41, obd_varchar42, obd_varchar43, obd_varchar44, obd_varchar45, obd_varchar46, obd_varchar47, obd_varchar48, obd_varchar49, obd_varchar50, obd_createddate, obd_createdby, obd_updateddate, obd_updatedby, obd_hidden, obd_deleted) VALUES ( ");
                        sSQL.Append(p.Language.ToString() + ", ");
                        sSQL.Append(p.ParentId.ToString() + ", ");
                        sSQL.Append(p.SitId.ToString() + ", ");
                        sSQL.Append(p.PagId.ToString() + ", ");
                        sSQL.Append(p.ModId.ToString() + ", ");
                        sSQL.Append(Convert.ToString((Int32)OrderMinMax.Max) + ", ");
                        sSQL.Append(Convert.ToString((Int32)p.ObjectType) + ", ");
                        sSQL.Append("'" + p.Name + "', ");
                        sSQL.Append("'" + p.Alias + "', ");
                        sSQL.Append("'" + p.Description + "', ");
                        sSQL.Append("'" + p.Field1 + "', ");
                        sSQL.Append("'" + p.Field2 + "', ");
                        sSQL.Append("'" + p.Field3 + "', ");
                        sSQL.Append("'" + p.Field4 + "', ");
                        sSQL.Append("'" + p.Field5 + "', ");
                        sSQL.Append("'" + p.Field6 + "', ");
                        sSQL.Append("'" + p.Field7 + "', ");
                        sSQL.Append("'" + p.Field8 + "', ");
                        sSQL.Append("'" + p.Field9 + "', ");
                        sSQL.Append("'" + p.Field10 + "', ");
                        sSQL.Append("'" + p.Field11 + "', ");
                        sSQL.Append("'" + p.Field12 + "', ");
                        sSQL.Append("'" + p.Field13 + "', ");
                        sSQL.Append("'" + p.Field14 + "', ");
                        sSQL.Append("'" + p.Field15 + "', ");
                        sSQL.Append("'" + p.Field16 + "', ");
                        sSQL.Append("'" + p.Field17 + "', ");
                        sSQL.Append("'" + p.Field18 + "', ");
                        sSQL.Append("'" + p.Field19 + "', ");
                        sSQL.Append("'" + p.Field20 + "', ");
                        sSQL.Append("'" + p.Field21 + "', ");
                        sSQL.Append("'" + p.Field22 + "', ");
                        sSQL.Append("'" + p.Field23 + "', ");
                        sSQL.Append("'" + p.Field24 + "', ");
                        sSQL.Append("'" + p.Field25 + "', ");
                        sSQL.Append("'" + p.Field26 + "', ");
                        sSQL.Append("'" + p.Field27 + "', ");
                        sSQL.Append("'" + p.Field28 + "', ");
                        sSQL.Append("'" + p.Field29 + "', ");
                        sSQL.Append("'" + p.Field30 + "', ");
                        sSQL.Append("'" + p.Field31 + "', ");
                        sSQL.Append("'" + p.Field32 + "', ");
                        sSQL.Append("'" + p.Field33 + "', ");
                        sSQL.Append("'" + p.Field34 + "', ");
                        sSQL.Append("'" + p.Field35 + "', ");
                        sSQL.Append("'" + p.Field36 + "', ");
                        sSQL.Append("'" + p.Field37 + "', ");
                        sSQL.Append("'" + p.Field38 + "', ");
                        sSQL.Append("'" + p.Field39 + "', ");
                        sSQL.Append("'" + p.Field40 + "', ");
                        sSQL.Append("'" + p.Field41 + "', ");
                        sSQL.Append("'" + p.Field42 + "', ");
                        sSQL.Append("'" + p.Field43 + "', ");
                        sSQL.Append("'" + p.Field44 + "', ");
                        sSQL.Append("'" + p.Field45 + "', ");
                        sSQL.Append("'" + p.Field46 + "', ");
                        sSQL.Append("'" + p.Field47 + "', ");
                        sSQL.Append("'" + p.Field48 + "', ");
                        sSQL.Append("'" + p.Field49 + "', ");
                        sSQL.Append("'" + p.Field50 + "', ");
                        sSQL.Append("'" + DateTime.Now.ToString() + "', ");
                        if (HttpContext.Current != null) { sSQL.Append("'" + RXServer.Authentication.User.Identity.Name + "', "); } else { sSQL.Append("'NoIdentity', "); }
                        sSQL.Append("'" + DateTime.Now.ToString() + "', ");
                        if (HttpContext.Current != null) { sSQL.Append("'" + RXServer.Authentication.User.Identity.Name + "', "); } else { sSQL.Append("'NoIdentity', "); }
                        sSQL.Append("0, ");
                        sSQL.Append("0)");
                        using (iCDataObject oDo = new iCDataObject(this.m_datasource, this.m_connectionstring, false, true, true))
                        {
                            Int32 ret = oDo.ExecuteNonQuery(sSQL.ToString());
                            p.Id = Convert.ToInt32(oDo.GetDataTable("SELECT @@Identity").Rows[0][0]);
                        }
                        SortAll();
                        GetAll();
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, "");
                    }
                }
                public void Remove(PageFlipItem p)
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::Remove]";
                    try
                    {
                        this.Remove(p.Id);
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, "");
                    }
                }
                public void Remove(Int32 Id)
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::Remove]";
                    try
                    {
                        StringBuilder sSQL = new StringBuilder();
                        sSQL.Append("UPDATE obd_objectdata SET obd_deleted = 1 ");
                        sSQL.Append("WHERE obd_id = " + Id.ToString());
                        using (iCDataObject oDo = new iCDataObject(this.m_datasource, this.m_connectionstring, false, true, true))
                            oDo.ExecuteNonQuery(sSQL.ToString());
                        SortAll();
                        GetAll();
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, "");
                    }
                }
                public void Clear()
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::Clear]";
                    try
                    {
                        this.m_objects = null;
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, "");
                    }
                }
                public Int32 Count()
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::Count]";
                    try
                    {
                        return this.m_objects.Length;
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, "");
                        return 0;
                    }
                }
                public DataTable DataTable()
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::DataTable]";
                    try
                    {
                        return this.m_dtobjects;
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, "");
                        return new DataTable();
                    }
                }
                public DataTable DataTable(ObjectSortField SortField, SortOrder SortOrder)
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::DataTable]";
                    try
                    {
                        DataView v = new DataView(m_dtobjects);
                        v.Sort = RetriveSortField(SortField) + Convert.ToString((Int32)SortOrder == 1 ? String.Empty : " DESC");
                        return v.ToTable();
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, "");
                        return new DataTable();
                    }
                }
                public void Save()
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::Save]";
                    try
                    {
                        XmlTextWriter textWriter = new XmlTextWriter(this.m_path, null);
                        textWriter.WriteStartDocument();
                        textWriter.WriteComment("This file is generated by RXServer and");
                        textWriter.WriteComment("should not be configured by hand.");
                        textWriter.WriteStartElement("content");
                        textWriter.WriteAttributeString("width", this.m_width);
                        textWriter.WriteAttributeString("height", this.m_height);
                        textWriter.WriteAttributeString("hcover", this.m_hcover ? "true" : "false");
                        textWriter.WriteAttributeString("transparency", this.m_transparency ? "true" : "false");
                        textWriter.WriteAttributeString("prepage", this.m_prepage);

                        foreach (PageFlipItem p in this.m_objects)
                        {
                            textWriter.WriteStartElement("page", "");
                            textWriter.WriteAttributeString("src", p.Src);
                            textWriter.WriteAttributeString("preLoad", p.PreLoad ? "true" : "false");
                            textWriter.WriteEndElement();
                        }

                        textWriter.WriteEndElement();

                        textWriter.WriteEndDocument();
                        textWriter.Close();
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, "");
                    }
                }

                #endregion Public Methods

                #region Private Methods

                private void ResetThis()
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::ResetThis]";
                    try
                    {
                        RXServer.Data.ResetCache(RXServer.Data.CACHEITEM_OBJECT_ID);
                        RXServer.Data.ResetCache(RXServer.Data.CACHEITEM_OBJECT_ALIAS);
                        RXServer.Data.ResetCache(RXServer.Data.CACHEITEM_OBJECT_COLLECTION);
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, "");
                    }
                }
                private String RetriveSortField(ObjectSortField SortField)
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::RetriveSortField]";
                    try
                    {

                        if ((Int32)SortField == 1) return "obd_id";
                        if ((Int32)SortField == 2) return "lng_id";
                        if ((Int32)SortField == 3) return "obd_parentid";
                        if ((Int32)SortField == 4) return "sit_id";
                        if ((Int32)SortField == 5) return "pag_id";
                        if ((Int32)SortField == 64) return "mod_id";
                        if ((Int32)SortField == 6) return "obd_order";
                        if ((Int32)SortField == 7) return "obd_title";
                        if ((Int32)SortField == 8) return "obd_alias";
                        if ((Int32)SortField == 9) return "obd_description";
                        if ((Int32)SortField == 10) return "obd_varchar1";
                        if ((Int32)SortField == 11) return "obd_varchar2";
                        if ((Int32)SortField == 12) return "obd_varchar3";
                        if ((Int32)SortField == 13) return "obd_varchar4";
                        if ((Int32)SortField == 14) return "obd_varchar5";
                        if ((Int32)SortField == 15) return "obd_varchar6";
                        if ((Int32)SortField == 16) return "obd_varchar7";
                        if ((Int32)SortField == 17) return "obd_varchar8";
                        if ((Int32)SortField == 18) return "obd_varchar9";
                        if ((Int32)SortField == 19) return "obd_varchar10";
                        if ((Int32)SortField == 20) return "obd_varchar11";
                        if ((Int32)SortField == 21) return "obd_varchar12";
                        if ((Int32)SortField == 22) return "obd_varchar13";
                        if ((Int32)SortField == 23) return "obd_varchar14";
                        if ((Int32)SortField == 24) return "obd_varchar15";
                        if ((Int32)SortField == 25) return "obd_varchar16";
                        if ((Int32)SortField == 26) return "obd_varchar17";
                        if ((Int32)SortField == 27) return "obd_varchar18";
                        if ((Int32)SortField == 28) return "obd_varchar19";
                        if ((Int32)SortField == 29) return "obd_varchar20";
                        if ((Int32)SortField == 30) return "obd_varchar21";
                        if ((Int32)SortField == 31) return "obd_varchar22";
                        if ((Int32)SortField == 32) return "obd_varchar23";
                        if ((Int32)SortField == 33) return "obd_varchar24";
                        if ((Int32)SortField == 34) return "obd_varchar25";
                        if ((Int32)SortField == 35) return "obd_varchar26";
                        if ((Int32)SortField == 36) return "obd_varchar27";
                        if ((Int32)SortField == 37) return "obd_varchar28";
                        if ((Int32)SortField == 38) return "obd_varchar29";
                        if ((Int32)SortField == 39) return "obd_varchar30";
                        if ((Int32)SortField == 40) return "obd_varchar31";
                        if ((Int32)SortField == 41) return "obd_varchar32";
                        if ((Int32)SortField == 42) return "obd_varchar33";
                        if ((Int32)SortField == 43) return "obd_varchar34";
                        if ((Int32)SortField == 44) return "obd_varchar35";
                        if ((Int32)SortField == 45) return "obd_varchar36";
                        if ((Int32)SortField == 46) return "obd_varchar37";
                        if ((Int32)SortField == 47) return "obd_varchar38";
                        if ((Int32)SortField == 48) return "obd_varchar39";
                        if ((Int32)SortField == 49) return "obd_varchar40";
                        if ((Int32)SortField == 50) return "obd_varchar41";
                        if ((Int32)SortField == 51) return "obd_varchar42";
                        if ((Int32)SortField == 52) return "obd_varchar43";
                        if ((Int32)SortField == 53) return "obd_varchar44";
                        if ((Int32)SortField == 54) return "obd_varchar45";
                        if ((Int32)SortField == 55) return "obd_varchar46";
                        if ((Int32)SortField == 56) return "obd_varchar47";
                        if ((Int32)SortField == 57) return "obd_varchar48";
                        if ((Int32)SortField == 58) return "obd_varchar49";
                        if ((Int32)SortField == 59) return "obd_varchar50";
                        if ((Int32)SortField == 60) return "obd_createddate";
                        if ((Int32)SortField == 61) return "obd_createdby";
                        if ((Int32)SortField == 62) return "obd_updateddate";
                        if ((Int32)SortField == 63) return "obd_updatedby";
                        return String.Empty;
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, "");
                        return String.Empty;
                    }
                }
                private void SortAll()
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::SortAll]";
                    if (!this.Refresh)
                        return;
                    try
                    {
                        Int32 Order = (Int32)OrderMinMax.Min;
                        StringBuilder sSQL = new StringBuilder();
                        sSQL.Append("SELECT * FROM obd_objectdata WHERE obd_deleted = 0 ORDER BY sit_id, pag_id, mod_id, obd_order");
                        using (iCDataObject oDo = new iCDataObject(this.m_datasource, this.m_connectionstring, false, true, false))
                        {
                            DataTable dt = oDo.GetDataTable(sSQL.ToString());
                            foreach (DataRow dr in dt.Rows)
                            {
                                StringBuilder sSQL2 = new StringBuilder();
                                sSQL2.Append("UPDATE obd_objectdata SET obd_order = " + Order.ToString() + " WHERE obd_id = " + dr["obd_id"].ToString());
                                using (iCDataObject oDo2 = new iCDataObject(this.m_datasource, this.m_connectionstring, false, true, false))
                                    oDo2.ExecuteNonQuery(sSQL2.ToString());
                                Order = Order + (Int32)OrderMinMax.Step;
                                RXServer.Data.ResetCache(RXServer.Data.CACHEITEM_OBJECT_ID + dr["obd_id"].ToString());
                                RXServer.Data.ResetCache(RXServer.Data.CACHEITEM_OBJECT_ID + dr["obd_alias"].ToString());
                            }
                            ResetThis();
                        }
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, "");
                    }
                }
                private void GetAll()
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::GetAll]";
                    DataTable dt = null;
                    if (!this.Refresh)
                        return;
                    try
                    {
                        String CacheItem = RXServer.Data.CACHEITEM_OBJECT_COLLECTION +
                            "::SitId" + this.m_sit_id.ToString() +
                            "::PagId" + this.m_pag_id.ToString() +
                            "::ModId" + this.m_mod_id.ToString() +
                            "::ObdType" + Convert.ToString((Int32)this.m_objecttype);
                        if (HttpContext.Current != null) if (HttpContext.Current != null) dt = (DataTable)HttpContext.Current.Cache[CacheItem];
                        if (dt == null)
                        {
                            StringBuilder sSQL = new StringBuilder();
                            sSQL.Append("SELECT * FROM obd_objectdata WHERE sit_id = " + this.m_sit_id.ToString() + " AND pag_id = " + this.m_pag_id.ToString() + " AND mod_id = " + this.m_mod_id.ToString() + Convert.ToString(this.m_objecttype != ObjectType.Undefined ? " AND obd_type = " + Convert.ToString((Int32)this.m_objecttype) : String.Empty) + " AND obd_deleted = 0 ORDER BY obd_order");
                            using (iCDataObject oDo = new iCDataObject(this.m_datasource, this.m_connectionstring, false, true, false))
                            {
                                dt = oDo.GetDataTable(sSQL.ToString());
                            }
                            RXServer.Data.CacheInsert(CacheItem, dt);
                        }
                        if (dt.Rows.Count > 0)
                        {
                            this.m_dtobjects = dt;
                            Int32 index = 0;
                            this.m_objects = new PageFlipItem[dt.Rows.Count];
                            foreach (DataRow dr in dt.Rows)
                            {
                                this.m_objects[index] = new PageFlipItem();
                                this.m_objects[index].Id = Convert.ToInt32(dr["obd_id"]);
                                this.m_objects[index].Language = Convert.ToInt32(dr["lng_id"]);
                                this.m_objects[index].ParentId = Convert.ToInt32(dr["obd_parentid"]);
                                this.m_objects[index].Order = Convert.ToInt32(dr["obd_order"]);
                                this.m_objects[index].ObjectType = (ObjectType)Convert.ToInt32(dr["obd_type"]);
                                this.m_objects[index].Name = Convert.ToString(dr["obd_title"]);
                                this.m_objects[index].Alias = Convert.ToString(dr["obd_alias"]);
                                this.m_objects[index].Description = Convert.ToString(dr["obd_description"]);
                                this.m_objects[index].Field1 = Convert.ToString(dr["obd_varchar1"]);
                                this.m_objects[index].Field2 = Convert.ToString(dr["obd_varchar2"]);
                                this.m_objects[index].Field3 = Convert.ToString(dr["obd_varchar3"]);
                                this.m_objects[index].Field4 = Convert.ToString(dr["obd_varchar4"]);
                                this.m_objects[index].Field5 = Convert.ToString(dr["obd_varchar5"]);
                                this.m_objects[index].Field6 = Convert.ToString(dr["obd_varchar6"]);
                                this.m_objects[index].Field7 = Convert.ToString(dr["obd_varchar7"]);
                                this.m_objects[index].Field8 = Convert.ToString(dr["obd_varchar8"]);
                                this.m_objects[index].Field9 = Convert.ToString(dr["obd_varchar9"]);
                                this.m_objects[index].Field10 = Convert.ToString(dr["obd_varchar10"]);
                                this.m_objects[index].Field11 = Convert.ToString(dr["obd_varchar11"]);
                                this.m_objects[index].Field12 = Convert.ToString(dr["obd_varchar12"]);
                                this.m_objects[index].Field13 = Convert.ToString(dr["obd_varchar13"]);
                                this.m_objects[index].Field14 = Convert.ToString(dr["obd_varchar14"]);
                                this.m_objects[index].Field15 = Convert.ToString(dr["obd_varchar15"]);
                                this.m_objects[index].Field16 = Convert.ToString(dr["obd_varchar16"]);
                                this.m_objects[index].Field17 = Convert.ToString(dr["obd_varchar17"]);
                                this.m_objects[index].Field18 = Convert.ToString(dr["obd_varchar18"]);
                                this.m_objects[index].Field19 = Convert.ToString(dr["obd_varchar19"]);
                                this.m_objects[index].Field20 = Convert.ToString(dr["obd_varchar20"]);
                                this.m_objects[index].Field21 = Convert.ToString(dr["obd_varchar21"]);
                                this.m_objects[index].Field22 = Convert.ToString(dr["obd_varchar22"]);
                                this.m_objects[index].Field23 = Convert.ToString(dr["obd_varchar23"]);
                                this.m_objects[index].Field24 = Convert.ToString(dr["obd_varchar24"]);
                                this.m_objects[index].Field25 = Convert.ToString(dr["obd_varchar25"]);
                                this.m_objects[index].Field26 = Convert.ToString(dr["obd_varchar26"]);
                                this.m_objects[index].Field27 = Convert.ToString(dr["obd_varchar27"]);
                                this.m_objects[index].Field28 = Convert.ToString(dr["obd_varchar28"]);
                                this.m_objects[index].Field29 = Convert.ToString(dr["obd_varchar29"]);
                                this.m_objects[index].Field30 = Convert.ToString(dr["obd_varchar30"]);
                                this.m_objects[index].Field31 = Convert.ToString(dr["obd_varchar31"]);
                                this.m_objects[index].Field32 = Convert.ToString(dr["obd_varchar32"]);
                                this.m_objects[index].Field33 = Convert.ToString(dr["obd_varchar33"]);
                                this.m_objects[index].Field34 = Convert.ToString(dr["obd_varchar34"]);
                                this.m_objects[index].Field35 = Convert.ToString(dr["obd_varchar35"]);
                                this.m_objects[index].Field36 = Convert.ToString(dr["obd_varchar36"]);
                                this.m_objects[index].Field37 = Convert.ToString(dr["obd_varchar37"]);
                                this.m_objects[index].Field38 = Convert.ToString(dr["obd_varchar38"]);
                                this.m_objects[index].Field39 = Convert.ToString(dr["obd_varchar39"]);
                                this.m_objects[index].Field40 = Convert.ToString(dr["obd_varchar40"]);
                                this.m_objects[index].Field41 = Convert.ToString(dr["obd_varchar41"]);
                                this.m_objects[index].Field42 = Convert.ToString(dr["obd_varchar42"]);
                                this.m_objects[index].Field43 = Convert.ToString(dr["obd_varchar43"]);
                                this.m_objects[index].Field44 = Convert.ToString(dr["obd_varchar44"]);
                                this.m_objects[index].Field45 = Convert.ToString(dr["obd_varchar45"]);
                                this.m_objects[index].Field46 = Convert.ToString(dr["obd_varchar46"]);
                                this.m_objects[index].Field47 = Convert.ToString(dr["obd_varchar47"]);
                                this.m_objects[index].Field48 = Convert.ToString(dr["obd_varchar48"]);
                                this.m_objects[index].Field49 = Convert.ToString(dr["obd_varchar49"]);
                                this.m_objects[index].Field50 = Convert.ToString(dr["obd_varchar50"]);
                                this.m_objects[index].CreatedDate = Convert.ToDateTime(dr["obd_createddate"]);
                                this.m_objects[index].CreatedBy = Convert.ToString(dr["obd_createdby"]);
                                this.m_objects[index].UpdatedDate = Convert.ToDateTime(dr["obd_updateddate"]);
                                this.m_objects[index].UpdatedBy = Convert.ToString(dr["obd_updatedby"]);
                                this.m_objects[index].Hidden = Convert.ToBoolean(dr["obd_hidden"]);
                                this.m_objects[index].Deleted = Convert.ToBoolean(dr["obd_deleted"]);
                                this.m_objects[index].Exist = true;
                                index++;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, "");
                    }
                }

                #endregion Private Methods

            }
            #endregion public class PageFlip

            #region public class PageFlipItem
            public class PageFlipItem : Object
            {
                string CLASSNAME = "[Namespace::RXServer::Web::Modules][Class::PageFlipItem]";

                public String Type
                {
                    get { return base.Field1; }
                    set { base.Field1 = value; }
                }
                public String Src
                {
                    get { return base.Field2; }
                    set { base.Field2 = value; }
                }
                public Boolean PreLoad
                {
                    get { return base.Field3.Equals("1") ? true : false; }
                    set { base.Field3 = value.Equals(true) ? "1" : "0"; }
                }
                
                public PageFlipItem(){}
                public PageFlipItem(Int32 SitId, Int32 PagId, Int32 ModId)
                    : base(ObjectType.RXServerDefined_Modules_PageFlipItem, SitId, PagId, ModId, RXServer.Data.DataSource, RXServer.Data.ConnectionString)
                {
                }
                public PageFlipItem(Int32 SitId, Int32 PagId, Int32 ModId, String Src, Boolean PreLoad)
                    : base(ObjectType.RXServerDefined_Modules_PageFlipItem, SitId, PagId, ModId, RXServer.Data.DataSource, RXServer.Data.ConnectionString)
                {
                    this.Src = Src;
                    this.PreLoad = PreLoad;
                    this.Save();
                }
                
                public override void Save()
                {
                    string FUNCTIONNAME = CLASSNAME + "[Function::Save]";
                    try
                    {
                        base.Name = "PageFlipItem";
                        base.Alias = "PageFlipItem";
                        base.Description = "PageFlipItem";
                        base.Save();
                    }
                    catch (Exception ex)
                    {
                        Error.Report(ex, FUNCTIONNAME, String.Empty);
                    }
                }
            }
            #endregion public class PageFlipItem

        }
    }
}
