using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using ImageQuantization;

namespace RXServer
{
    namespace Library
    {

        #region public class Mail
        public class Mail
        {
            //static string CLASSNAME = "[Namespace::RXServer::Library][Class::Mail]";
        }
        #endregion public class Mail

        #region public class File
        public static class File
        {
            static string CLASSNAME = "[Namespace::RXServer::Library][Class::File]";
            public static String GetTempFileName()
            {
                string FUNCTIONNAME = CLASSNAME + "[Function::GetTempFileName]";
                try
                {
                    return Path.GetFileNameWithoutExtension(Path.GetTempFileName());
                }
                catch (Exception ex)
                {
                    Error.Report(ex, FUNCTIONNAME, String.Empty);
                    return String.Empty;
                }
            }
        }
        #endregion public class File
        
        #region public class Image
        public static class Image
        {
            static string CLASSNAME = "[Namespace::RXServer::Library][Class::Image]";
            public static void CreateMenuItemImage(
                String _Text,
                Int32 _X,
                Int32 _Y,
                Int32[] _FontColor,
                String _FontName,
                float _FontSize,
                FontStyle _FontStyle,
                GraphicsUnit _FontUnit,
                String _SourceImageFileName,
                String _DestinationImageFileName)
            {
                string FUNCTIONNAME = CLASSNAME + "[Function::CreateMenuItemImage]";
                try
                {
                    Font f = new Font(_FontName, _FontSize, _FontStyle, _FontUnit);
                    SolidBrush sb = new SolidBrush(Color.FromArgb(_FontColor[0], _FontColor[1], _FontColor[2]));

                    Graphics g1 = Graphics.FromImage(new Bitmap(1, 1));
                    Int32 TextWidthInt32 = (Int32)g1.MeasureString(_Text, f).Width + 6;

                    System.Drawing.Image i1 = System.Drawing.Image.FromFile(_SourceImageFileName);
                    Bitmap b2 = new Bitmap(i1);

                    Bitmap b3 = b2.Clone(new RectangleF(0, 0, TextWidthInt32 > b2.Width ? b2.Width : TextWidthInt32, b2.Height), PixelFormat.DontCare);

                    Graphics g2 = Graphics.FromImage(b3);

                    g2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
                    g2.SmoothingMode = SmoothingMode.AntiAlias;
                    g2.DrawImage(b3, 10, 151);

                    g2.DrawString(_Text, f, sb, new RectangleF(_X, _Y, TextWidthInt32, 20), StringFormat.GenericDefault);

                    OctreeQuantizer quantizer = new OctreeQuantizer(255, 8);
                    using (Bitmap BMPQuantized = quantizer.Quantize(b3))
                    {
                        BMPQuantized.Save(_DestinationImageFileName, System.Drawing.Imaging.ImageFormat.Gif);
                    }
                }
                catch (Exception ex)
                {
                    Error.Report(ex, FUNCTIONNAME, String.Empty);
                }
            }

            public static void CreateTeaserImage(
                String _HeaderText,
                String _IngressText,
                Int32 _X,
                Int32 _Y,
                Int32[] _HeaderFontColor,
                String _HeaderFontName,
                float _HeaderFontSize,
                FontStyle _HeaderFontStyle,
                GraphicsUnit _HeaderFontUnit,
                Int32[] _IngressFontColor,
                String _IngressFontName,
                float _IngressFontSize,
                FontStyle _IngressFontStyle,
                GraphicsUnit _IngressFontUnit,
                String _SourceImageFileName,
                String _DestinationImageFileName)
            {
                string FUNCTIONNAME = CLASSNAME + "[Function::CreateTeaserImage]";
                try
                {
                    Font fHeader = new Font(_HeaderFontName, _HeaderFontSize, _HeaderFontStyle, _HeaderFontUnit);
                    Font fIngress = new Font(_IngressFontName, _IngressFontSize, _IngressFontStyle, _IngressFontUnit);
                    SolidBrush sbHeader = new SolidBrush(Color.FromArgb(_HeaderFontColor[0], _HeaderFontColor[1], _HeaderFontColor[2]));
                    SolidBrush sbIngress = new SolidBrush(Color.FromArgb(_IngressFontColor[0], _IngressFontColor[1], _IngressFontColor[2]));

                    Graphics g1 = Graphics.FromImage(new Bitmap(1, 1));
                    Int32 HeaderTextWidthInt32 = (Int32)g1.MeasureString(_HeaderText, fHeader).Width + 6;
                    Int32 IngressTextWidthInt32 = (Int32)g1.MeasureString(_IngressText, fIngress).Width + 6;

                    System.Drawing.Image i1 = System.Drawing.Image.FromFile(_SourceImageFileName);
                    Bitmap b2 = new Bitmap(i1);

                    Bitmap b3 = b2.Clone(new RectangleF(0, 0, b2.Width, b2.Height), PixelFormat.DontCare);

                    Graphics g2 = Graphics.FromImage(b3);
                    Graphics gi = Graphics.FromImage(b3);

                    g2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
                    g2.SmoothingMode = SmoothingMode.AntiAlias;
                    g2.DrawImage(b3, _X, _Y);
                    gi.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
                    gi.SmoothingMode = SmoothingMode.AntiAlias;
                    gi.DrawImage(b3, _X, _Y);

                    g2.DrawString(_HeaderText, fHeader, sbHeader, new RectangleF(_X, _Y, b2.Width - (_X * 2), 24), StringFormat.GenericDefault);
                    gi.DrawString(_IngressText, fIngress, sbIngress, new RectangleF(_X, _Y + 30, b2.Width - (_X * 2), 65), StringFormat.GenericDefault);

                    OctreeQuantizer quantizer = new OctreeQuantizer(255, 8);
                    using (Bitmap BMPQuantized = quantizer.Quantize(b3))
                    {
                        BMPQuantized.Save(_DestinationImageFileName, System.Drawing.Imaging.ImageFormat.Gif);
                    }
                }
                catch (Exception ex)
                {
                    Error.Report(ex, FUNCTIONNAME, String.Empty);
                }
            }

            public static void CreateHeaderImage(
                String _Text,
                Int32 _X,
                Int32 _Y,
                Int32[] _FontColor,
                String _FontName,
                float _FontSize,
                FontStyle _FontStyle,
                GraphicsUnit _FontUnit,
                String _SourceImageFileName,
                String _DestinationImageFileName)
            {
                string FUNCTIONNAME = CLASSNAME + "[Function::CreateHeaderImage]";
                try
                {
                    Font f = new Font(_FontName, _FontSize, _FontStyle, _FontUnit);
                    SolidBrush sb = new SolidBrush(Color.FromArgb(_FontColor[0], _FontColor[1], _FontColor[2]));

                    Graphics g1 = Graphics.FromImage(new Bitmap(1, 1));
                    Int32 TextWidthInt32 = (Int32)g1.MeasureString(_Text, f).Width + 6;

                    System.Drawing.Image i1 = System.Drawing.Image.FromFile(_SourceImageFileName);
                    Bitmap b2 = new Bitmap(i1);

                    Bitmap b3 = b2.Clone(new RectangleF(0, 0, TextWidthInt32 > b2.Width ? b2.Width : TextWidthInt32, b2.Height), PixelFormat.DontCare);

                    Graphics g2 = Graphics.FromImage(b3);

                    g2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
                    g2.SmoothingMode = SmoothingMode.AntiAlias;
                    g2.DrawImage(b3, 10, 151);

                    g2.DrawString(_Text, f, sb, new RectangleF(_X, _Y, TextWidthInt32, 20), StringFormat.GenericDefault);

                    OctreeQuantizer quantizer = new OctreeQuantizer(255, 8);
                    using (Bitmap BMPQuantized = quantizer.Quantize(b3))
                    {
                        BMPQuantized.Save(_DestinationImageFileName, System.Drawing.Imaging.ImageFormat.Gif);
                    }
                }
                catch (Exception ex)
                {
                    Error.Report(ex, FUNCTIONNAME, String.Empty);
                }
            }

            public static void CreateComboHeaderImage(
                String _TextFirst,
                Int32 _XFirst,
                Int32 _YFirst,
                Int32[] _FontColorFirst,
                String _FontNameFirst,
                float _FontSizeFirst,
                FontStyle _FontStyleFirst,
                GraphicsUnit _FontUnitFirst,
                String _TextSecond,
                Int32 _XSecond,
                Int32 _YSecond,
                Int32[] _FontColorSecond,
                String _FontNameSecond,
                float _FontSizeSecond,
                FontStyle _FontStyleSecond,
                GraphicsUnit _FontUnitSecond,
                String _SourceImageFileName,
                String _DestinationImageFileName)
            {
                string FUNCTIONNAME = CLASSNAME + "[Function::CreateComboHeaderImage]";
                try
                {
                    Font fFirst = new Font(_FontNameFirst, _FontSizeFirst, _FontStyleFirst, _FontUnitFirst);
                    Font fSecond = new Font(_FontNameSecond, _FontSizeSecond, _FontStyleSecond, _FontUnitSecond);
                    SolidBrush sbFirst = new SolidBrush(Color.FromArgb(_FontColorFirst[0], _FontColorFirst[1], _FontColorFirst[2]));
                    SolidBrush sbSecond = new SolidBrush(Color.FromArgb(_FontColorSecond[0], _FontColorSecond[1], _FontColorSecond[2]));

                    Graphics g1First = Graphics.FromImage(new Bitmap(1, 1));
                    Int32 TextWidthInt32First = (Int32)g1First.MeasureString(_TextFirst, fFirst).Width + (_XFirst * 2) + 2;
                    Int32 TextWidthInt32Second = (Int32)g1First.MeasureString(_TextSecond, fSecond).Width + (_XSecond * 2 + 2);

                    System.Drawing.Image i1First = System.Drawing.Image.FromFile(_SourceImageFileName);
                    Bitmap b2First = new Bitmap(i1First);

                    Bitmap b3First = b2First.Clone(new RectangleF(0, 0, (TextWidthInt32First + TextWidthInt32Second) > b2First.Width ? b2First.Width : (TextWidthInt32First + TextWidthInt32Second), b2First.Height), PixelFormat.DontCare);

                    Graphics g2First = Graphics.FromImage(b3First);

                    g2First.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
                    g2First.SmoothingMode = SmoothingMode.AntiAlias;
                    g2First.DrawImage(b3First, _XFirst, _YFirst);

                    //g2First.DrawString(_TextFirst, fFirst, sbFirst, new RectangleF(-3, -3, TextWidthInt32First, b2First.Height), StringFormat.GenericDefault);
                    //g2First.DrawString(_TextSecond, fSecond, sbSecond, new RectangleF(_XSecond + TextWidthInt32First, -3, (TextWidthInt32First + TextWidthInt32Second), b2First.Height), StringFormat.GenericDefault);

                    g2First.DrawString(_TextFirst, fFirst, sbFirst, new RectangleF(-3, 0, TextWidthInt32First, b2First.Height), StringFormat.GenericDefault);
                    g2First.DrawString(_TextSecond, fSecond, sbSecond, new RectangleF(_XSecond + TextWidthInt32First, 0, (TextWidthInt32First + TextWidthInt32Second), b2First.Height), StringFormat.GenericDefault);

                    OctreeQuantizer quantizer = new OctreeQuantizer(255, 8);
                    using (Bitmap BMPQuantized = quantizer.Quantize(b3First))
                    {
                        BMPQuantized.Save(_DestinationImageFileName, System.Drawing.Imaging.ImageFormat.Gif);
                    }
                }
                catch (Exception ex)
                {
                    Error.Report(ex, FUNCTIONNAME, String.Empty);
                }
            }
        }
        #endregion public class Image

    }
}
